﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web;
using System.Xml;
using System.Xml.Linq;
using CsvHelper;
using System.IO;
using System.Text;

namespace jQueryGridASPNET.Models
{
    public class GridModel
    {
        public List<Incident> GetIncidents(int? page, int? limit, string sortBy, string direction, string searchString, out int total)
        {
            var csvfile = HttpContext.Current.Server.MapPath("~/App_Data/chand.csv");
            TextReader textReader = File.OpenText(csvfile);
            var csv1 = new CsvReader(textReader);

            var csvdata = csv1.GetRecords<Incident>().ToList();
            total = csvdata.Count;
            textReader.Close();
            var records = (from p in csvdata
                           select new Incident
                           {
                               ID = int.Parse(p.ID.ToString()),
                               IncidentNo = p.IncidentNo,
                               ConfigurableItem = p.ConfigurableItem,
                               IncidentUpdate = p.IncidentUpdate
                           }).AsQueryable();

            if (!string.IsNullOrWhiteSpace(searchString))
            {
                records = records.Where(p => p.IncidentNo.Contains(searchString) || p.ConfigurableItem.Contains(searchString));
            }

            if (!string.IsNullOrEmpty(sortBy) && !string.IsNullOrEmpty(direction))
            {
                if (direction.Trim().ToLower() == "asc")
                {
                    records = SortHelper.OrderBy(records, sortBy);
                }
                else
                {
                    records = SortHelper.OrderByDescending(records, sortBy);
                }
            }

            if (page.HasValue && limit.HasValue)
            {
                int start = (page.Value - 1) * limit.Value;
                records = records.Skip(start).Take(limit.Value);
            }

            return records.ToList();
        }

        public void Save(Incident incident)
        {
            var csvfile = HttpContext.Current.Server.MapPath("~/App_Data/chand.csv");
            TextReader textReader = File.OpenText(csvfile);
            var csv1 = new CsvReader(textReader);
            var csvdata = csv1.GetRecords<Incident>().ToList();
            if (incident.ID > 0)
            {
                var record = (from p in csvdata
                              where int.Parse(p.ID.ToString()) == incident.ID
                              select p).FirstOrDefault();

                if (record != null)
                {
                    record.IncidentNo = incident.IncidentNo;
                    record.ConfigurableItem = incident.ConfigurableItem;
                    record.IncidentUpdate = incident.IncidentUpdate;

                }


            }
            else
            {
                int? maxId = (from p in csvdata select int.Parse(p.ID.ToString())).OrderByDescending(p => p).FirstOrDefault();
                int newId = maxId.HasValue ? (maxId.Value + 1) : 1;
                var record = new Incident
                {
                    ID = newId,
                    IncidentUpdate = incident.IncidentUpdate,
                    IncidentNo = incident.IncidentNo,
                    ConfigurableItem = incident.ConfigurableItem

                };

                csvdata.Add(record);

            }
            textReader.Close();
            using (TextWriter writer = new StreamWriter(csvfile))
            {
                var csv = new CsvWriter(writer);
                csv.Configuration.Encoding = Encoding.UTF8;
                csv.WriteRecords(csvdata);
            }
        }

        public void Delete(int id)
        {
            var csvfile = HttpContext.Current.Server.MapPath("~/App_Data/chand.csv");
            TextReader textReader = File.OpenText(csvfile);
            var csv1 = new CsvReader(textReader);
            var csvdata = csv1.GetRecords<Incident>().ToList();
            var record = (from p in csvdata
                          where int.Parse(p.ID.ToString()) == id
                          select p).FirstOrDefault();

            if (record != null)
            {
                csvdata.Remove(record);
                textReader.Close();
                using (TextWriter writer = new StreamWriter(csvfile))
                {
                    var csv = new CsvWriter(writer);
                    csv.WriteRecords(csvdata);
                }

            }


        }
        
    }
}