﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace jQueryGridASPNET.Models
{
    public class Incident
    {
        public int ID { get; set; }
        public string IncidentNo { get; set; }
        public string ConfigurableItem { get; set; }
        public string IncidentUpdate { get; set; }
    }
}